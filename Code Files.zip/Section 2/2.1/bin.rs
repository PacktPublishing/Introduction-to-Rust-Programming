extern crate mylib;
use mylib::demo;

pub fn main() {
demo();
}
